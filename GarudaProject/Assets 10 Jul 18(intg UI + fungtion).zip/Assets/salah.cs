﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class salah : MonoBehaviour {
    private void Start()
    {
        gameObject.SetActive(false);
        //Destroy(gameObject);
    }
    public void JawabanSalah()
    {
        //gameObject.SetActive(true);
        Debug.Log("Salah");
        
        Click.game = 0;
        gmScript.count = 0;
    }
}
