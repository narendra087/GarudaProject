﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class Click : MonoBehaviour {
    public static int game = 0;
    // Use this for initialization
    void Start () {

	}
	
	// Update is called once per frame
	void Update () {
		
	}

    private void OnMouseDown()
    {
        game = 1;
        gmScript.count++;      
        gmScript.currentWord += GetComponent<SpriteRenderer>().sprite.name;

        Debug.Log("Count = " + gmScript.count);
        Debug.Log(game);
    }
}
