﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class gmScript : MonoBehaviour
{
    public static string currentWord;
    public Transform spellWord;
    public Transform result;
    public Transform benar;
    public Transform salah;

    public static int count = 0;
    public static int cek = 0;
    // Use this for initialization
    void Start()
    {
        Debug.Log("Start Count = " + count);
    }

    // Update is called once per frame
    void Update()
    {
        string soal = "abc";

        spellWord.GetComponent<TextMesh>().text = currentWord;
        if (Click.game == 1)
        {
            if (currentWord == soal && count == 3)
            {
                //cek = 1;
                //FindObjectOfType<benar>().JawabanBenar();
                result.GetComponent<TextMesh>().text = "Benar";
            }
            else if (currentWord != soal && count == 3)
            {
                //FindObjectOfType<salah>().JawabanSalah();
                result.GetComponent<TextMesh>().text = "Salah";

                //Debug.Log("Anda Salah");
            }

        }        
    }
}
