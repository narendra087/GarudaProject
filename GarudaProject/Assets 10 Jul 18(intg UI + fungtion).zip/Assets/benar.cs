﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class benar : MonoBehaviour {
    

    private void Start()
    {
        gameObject.SetActive(false);
        //Destroy(gameObject);
    }

    private void Update()
    {
        
    }

    public void JawabanBenar()
    {
        //gameObject.SetActive(true);
        Debug.Log("Benar");
        
    }
}
